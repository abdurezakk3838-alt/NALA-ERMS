<?php
// logout.php
require_once 'includes/functions.php';

if (isset($_SESSION['user_name'])) {
    logAudit($_SESSION['user_name'], 'Logged Out', "User {$_SESSION['user_name']} logged out.");
}

session_destroy();
header('Location: login.php');
exit;
?>