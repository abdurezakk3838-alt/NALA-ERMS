<?php
// index.php
require_once 'includes/functions.php';
requireLogin();

$current_page = $_GET['page'] ?? 'dashboard';
$page_title = ucfirst(str_replace('_', ' ', $current_page));

// Check permission
if (!hasPermission($current_page)) {
    $current_page = 'dashboard';
}
?>
<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($_SESSION['language'] ?? 'en'); ?>" data-language="<?php echo htmlspecialchars($_SESSION['language'] ?? 'en'); ?>">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>NALA Enhanced Records Management</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
</head>
<body>
    <!-- Toast -->
    <div id="toast" class="toast">
        <i class="fas fa-check-circle text-green-400"></i>
        <div>
            <span id="toastMessage" class="font-semibold text-sm">Action Completed</span>
            <br />
            <span id="toastSubMessage" class="text-xs text-gray-300"></span>
        </div>
    </div>

    <!-- Main App -->
    <div id="appMain">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="main-content" id="mainContent">
            <?php include 'includes/header.php'; ?>
            
            <div class="p-6" id="pageContainer">
                <?php 
                $page_file = 'pages/' . $current_page . '.php';
                if (file_exists($page_file)) {
                    include $page_file;
                } else {
                    include 'pages/dashboard.php';
                }
                ?>
            </div>
        </div>
    </div>

    <!-- Modals -->
    <?php include 'includes/modals.php'; ?>

    <script src="assets/js/script.js"></script>
</body>
</html>
