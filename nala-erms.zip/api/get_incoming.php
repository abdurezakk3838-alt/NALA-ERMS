<?php
// api/get_incoming.php
require_once '../includes/functions.php';
requireLogin();

header('Content-Type: application/json');

$filters = [];
if (!empty($_GET['status'])) $filters['status'] = $_GET['status'];
if (!empty($_GET['receiver'])) $filters['receiver'] = $_GET['receiver'];
if (!empty($_GET['sender'])) $filters['sender'] = $_GET['sender'];
if (!empty($_GET['ref'])) $filters['ref'] = $_GET['ref'];

$letters = getIncomingLetters($filters);
echo json_encode(['success' => true, 'letters' => $letters]);