<?php
require_once '../includes/functions.php'; requireLogin();
header('Content-Type: application/json');
$question = trim($_POST['question'] ?? '');
if ($question === '') { echo json_encode(['success' => false, 'message' => 'Please enter a question.']); exit; }
$stats = getDashboardStats();
$q = strtolower($question);
if (strpos($q, 'pending') !== false || strpos($q, 'review') !== false) {
    $answer = 'There are ' . (($stats['pending_incoming'] ?? 0) + ($stats['pending_outgoing'] ?? 0) + ($stats['pending_internal'] ?? 0)) . ' documents waiting for review.';
} elseif (strpos($q, 'incoming') !== false) {
    $answer = 'The system currently has ' . ($stats['incoming_count'] ?? 0) . ' incoming letters.';
} elseif (strpos($q, 'outgoing') !== false) {
    $answer = 'The system currently has ' . ($stats['outgoing_count'] ?? 0) . ' outgoing letters.';
} elseif (strpos($q, 'help') !== false || strpos($q, 'how') !== false) {
    $answer = 'I can help with pending reviews, incoming letters, outgoing letters, notifications, and workflow navigation.';
} else {
    $answer = 'I can help you check pending reviews, incoming/outgoing counts, notifications, or workflow settings. For generative answers, configure an AI provider key in the server environment.';
}
echo json_encode(['success' => true, 'answer' => $answer]);
