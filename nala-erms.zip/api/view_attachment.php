<?php
require_once '../includes/functions.php';
requireLogin();

$ref = $_GET['ref'] ?? '';
$type = $_GET['type'] ?? 'incoming';

if (empty($ref)) {
    http_response_code(400);
    echo 'Reference number is required.';
    exit;
}

$letter = null;

switch ($type) {
    case 'incoming':
        $letter = getIncomingLetter($ref);
        break;
    case 'outgoing':
        $letter = getOutgoingLetter($ref);
        break;
    case 'internal':
        $letter = getInternalMemo($ref);
        break;
}

if (!$letter) {
    http_response_code(404);
    echo 'Attachment not found.';
    exit;
}

$fileName = $letter['file_name'] ?? 'attachment';
$extension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
$fileData = $letter['file_data'] ?? '';

// Older incoming letters may have an empty file_data value because the
// temporary upload was read after it had already been moved. Fall back to the
// safely stored upload filename for those records.
if ($fileData === '' && !empty($letter['file_name'])) {
    $storedPath = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . basename($letter['file_name']);
    if (is_file($storedPath) && is_readable($storedPath)) {
        $fileData = file_get_contents($storedPath);
    }
}

if ($fileData === '' || $fileData === false) {
    http_response_code(404);
    echo 'Attachment data is unavailable.';
    exit;
}

// Support both plain base64 data and data-URI values.
if (strpos($fileData, 'base64,') !== false) {
    $fileData = substr($fileData, strpos($fileData, 'base64,') + 7);
}

$decoded = base64_decode($fileData, true);
if ($decoded !== false) {
    $binary = $decoded;
} else {
    $binary = $fileData;
}

$mimeTypes = [
    'pdf' => 'application/pdf',
    'png' => 'image/png',
    'jpg' => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'gif' => 'image/gif',
    'webp' => 'image/webp',
    'txt' => 'text/plain; charset=utf-8',
    'html' => 'text/html; charset=utf-8',
    'csv' => 'text/csv; charset=utf-8',
];

$mimeType = $mimeTypes[$extension] ?? 'application/octet-stream';

header('Content-Type: ' . $mimeType);
header('Content-Disposition: inline; filename="' . basename($fileName) . '"');
header('Cache-Control: private, no-cache, no-store, must-revalidate');
echo $binary;
exit;
