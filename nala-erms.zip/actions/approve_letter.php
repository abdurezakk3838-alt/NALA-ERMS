<?php
// actions/approve_letter.php
require_once '../includes/functions.php';
requireLogin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$ref = $_POST['ref'] ?? '';
$type = $_POST['type'] ?? 'incoming';
$remark = $_POST['remark'] ?? '';
$signature = $_POST['signature'] ?? '';

if (empty($ref)) {
    echo json_encode(['success' => false, 'message' => 'Reference is required']);
    exit;
}

if (empty($signature)) {
    echo json_encode(['success' => false, 'message' => 'Digital signature is required']);
    exit;
}

$result = false;
$sourceTable = '';
$letter = null;

if (!in_array($type, ['incoming', 'outgoing', 'internal'], true)) {
    echo json_encode(['success' => false, 'message' => 'Invalid document type']);
    exit;
}

$pdo->beginTransaction();

switch ($type) {
    case 'incoming':
        $letter = getIncomingLetter($ref);
        if ($letter && canReviewDocument($letter, $type)) {
            $sourceTable = 'incoming_letters';
            $data = [
                'status' => 'approved',
                'receiver_remark' => $remark,
                'digital_signature' => $signature,
                'signed_by' => $_SESSION['user_name'],
                'signed_date' => date('Y-m-d H:i:s')
            ];
            $result = updateIncomingLetter($ref, $data);
        }
        break;
        
    case 'outgoing':
        $letter = getOutgoingLetter($ref);
        if ($letter && canReviewDocument($letter, $type)) {
            $sourceTable = 'outgoing_letters';
            $data = [
                'status' => 'approved',
                'manager_remark' => $remark,
                'digital_signature' => $signature,
                'signed_by' => $_SESSION['user_name'],
                'signed_date' => date('Y-m-d H:i:s')
            ];
            $result = updateOutgoingLetter($ref, $data);
        }
        break;
        
    case 'internal':
        $letter = getInternalMemo($ref);
        if ($letter && canReviewDocument($letter, $type)) {
            $sourceTable = 'internal_memos';
            $data = [
                'status' => 'approved',
                'receiver_remark' => $remark,
                'digital_signature' => $signature,
                'signed_by' => $_SESSION['user_name'],
                'signed_date' => date('Y-m-d H:i:s')
            ];
            $result = updateInternalMemo($ref, $data);
        }
        break;
        
}

if (!$result) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'This document is not available for your approval.']);
    exit;
}

try {
    $updatedLetter = $type === 'incoming' ? getIncomingLetter($ref) : ($type === 'outgoing' ? getOutgoingLetter($ref) : getInternalMemo($ref));
    if (!archiveDocument($sourceTable, $updatedLetter)) {
        throw new RuntimeException('Unable to archive the approved document.');
    }
    logAudit($_SESSION['user_name'], ucfirst($type) . ' Letter Approved and Archived', "Ref: $ref");
    $pdo->commit();
    echo json_encode(['success' => true, 'message' => 'Document approved and saved to the archive.']);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(['success' => false, 'message' => 'Document was approved, but could not be archived. Please contact the records office.']);
}
