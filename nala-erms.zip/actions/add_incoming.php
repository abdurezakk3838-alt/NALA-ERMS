<?php
// actions/add_incoming.php
require_once '../includes/functions.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ref_number = trim($_POST['ref_number'] ?? '');
    if ($ref_number === '') {
        $ref_number = generateRefNumber();
    }
    $sender_unique_num = $_POST['sender_unique_num'] ?? '';
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $sender_name = $_POST['sender_name'] ?? '';
    $receiver_name = $_POST['receiver_name'] ?? '';
    $receiver_email = $_POST['receiver_email'] ?? '';
    $received_date = $_POST['received_date'] ?? date('Y-m-d');
    $classification = $_POST['classification'] ?? 'General';
    $keywords = $_POST['keywords'] ?? '';
    $edit_ref = $_POST['edit_ref_number'] ?? '';
    
    // Handle file upload
    $file_name = null;
    $file_data = null;
    if (isset($_FILES['attached_file']) && $_FILES['attached_file']['error'] === UPLOAD_ERR_OK) {
        // Read the temporary upload before uploadFile() moves it.
        $raw_file_data = file_get_contents($_FILES['attached_file']['tmp_name']);
        $uploaded_file = uploadFile($_FILES['attached_file']);
        if ($uploaded_file) {
            $file_name = $uploaded_file;
            $file_data = base64_encode($raw_file_data);
        }
    }
    
    if ($edit_ref) {
        // Update existing letter
        $data = [
            'sender_unique_num' => $sender_unique_num,
            'title' => $title,
            'description' => $description,
            'sender_name' => $sender_name,
            'receiver_name' => $receiver_name,
            'receiver_email' => $receiver_email,
            'received_date' => $received_date,
            'classification' => $classification,
            'keywords' => $keywords,
        ];
        if ($file_name) {
            $data['file_name'] = $file_name;
            $data['file_data'] = $file_data;
        }
        $result = updateIncomingLetter($edit_ref, $data);
        logAudit($_SESSION['user_name'], 'Incoming Letter Updated', "Ref: $edit_ref");
        $message = 'Letter updated successfully.';
    } else {
        // Create new letter
        $data = [
            'ref_number' => $ref_number,
            'sender_unique_num' => $sender_unique_num,
            'title' => $title,
            'description' => $description,
            'sender_name' => $sender_name,
            'receiver_name' => $receiver_name,
            'receiver_email' => $receiver_email,
            'received_date' => $received_date,
            'classification' => $classification,
            'keywords' => $keywords,
            'status' => 'pending',
            'file_name' => $file_name,
            'file_data' => $file_data,
        ];
        $result = createIncomingLetter($data);
        if ($result) notifyReceiverAboutDocument($receiver_name, $title, $ref_number, 'incoming');
        logAudit($_SESSION['user_name'], 'Incoming Letter Created', "Ref: $ref_number");
        $message = 'Letter registered successfully.';
    }
    
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = $result ? 'success' : 'error';
    
    header('Location: ../index.php?page=incoming');
    exit;
} else {
    header('Location: ../index.php?page=incoming');
    exit;
}
?>
