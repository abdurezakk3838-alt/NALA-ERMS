<?php
// actions/dispatch_outgoing.php
require_once '../includes/functions.php';
requireLogin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$ref = $_POST['ref'] ?? '';

if (empty($ref)) {
    echo json_encode(['success' => false, 'message' => 'Reference is required']);
    exit;
}

$letter = getOutgoingLetter($ref);
if (!$letter) {
    echo json_encode(['success' => false, 'message' => 'Letter not found']);
    exit;
}

if ($letter['status'] !== 'approved') {
    echo json_encode(['success' => false, 'message' => 'Letter must be approved before dispatch']);
    exit;
}

$data = ['status' => 'dispatched'];
$result = updateOutgoingLetter($ref, $data);

if ($result) {
    logAudit($_SESSION['user_name'], 'Outgoing Letter Dispatched', "Ref: $ref");
    echo json_encode(['success' => true, 'message' => 'Letter dispatched successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to dispatch letter']);
}