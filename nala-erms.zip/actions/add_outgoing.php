<?php
// actions/add_outgoing.php
require_once '../includes/functions.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ref_number = $_POST['ref_number'] ?? generateOutRefNumber();
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $sender_name = $_POST['sender_name'] ?? $_SESSION['user_name'];
    $receiver_name = $_POST['receiver_name'] ?? '';
    $receiver_email = $_POST['receiver_email'] ?? '';
    $classification = $_POST['classification'] ?? 'General';
    $date = $_POST['date'] ?? date('Y-m-d');
    $edit_ref = $_POST['edit_out_ref'] ?? '';

    // Handle file upload
    $file_name = null;
    $file_data = null;
    if (isset($_FILES['attached_file']) && $_FILES['attached_file']['error'] === UPLOAD_ERR_OK) {
        $raw_file_data = file_get_contents($_FILES['attached_file']['tmp_name']);
        $uploaded_file = uploadFile($_FILES['attached_file']);
        if ($uploaded_file) {
            $file_name = $uploaded_file;
            $file_data = base64_encode($raw_file_data);
        }
    }

    if ($edit_ref) {
        // Update existing outgoing letter
        $data = [
            'title' => $title,
            'description' => $description,
            'sender_name' => $sender_name,
            'receiver_name' => $receiver_name,
            'receiver_email' => $receiver_email,
            'classification' => $classification,
            'date' => $date,
        ];
        if ($file_name) {
            $data['file_name'] = $file_name;
            $data['file_data'] = $file_data;
        }
        $result = updateOutgoingLetter($edit_ref, $data);
        logAudit($_SESSION['user_name'], 'Outgoing Letter Updated', "Ref: $edit_ref");
        $message = 'Outgoing letter updated successfully.';
    } else {
        // Create new outgoing letter
        $data = [
            'ref_number' => $ref_number,
            'title' => $title,
            'description' => $description,
            'sender_name' => $sender_name,
            'receiver_name' => $receiver_name,
            'receiver_email' => $receiver_email,
            'classification' => $classification,
            'date' => $date,
            'status' => 'pending_approval',
            'file_name' => $file_name,
            'file_data' => $file_data,
        ];
        $result = createOutgoingLetter($data);
        if ($result) notifyReceiverAboutDocument($receiver_name, $title, $ref_number, 'outgoing');
        logAudit($_SESSION['user_name'], 'Outgoing Letter Created', "Ref: $ref_number");
        $message = 'Outgoing letter created and submitted for approval.';
    }

    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = $result ? 'success' : 'error';

    header('Location: ../index.php?page=outgoing');
    exit;
} else {
    header('Location: ../index.php?page=outgoing');
    exit;
}
