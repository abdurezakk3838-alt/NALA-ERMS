<?php
// includes/functions.php
require_once __DIR__ . '/../config/database.php';

// User functions
function getUserByUsername($username) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    return $stmt->fetch();
}

function getUserByEmail($email) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    return $stmt->fetch();
}

function getUserRole($username) {
    $user = getUserByUsername($username);
    return $user ? $user['role'] : null;
}

function getRoleConfig($role) {
    $configs = [
        'head_office' => ['title' => 'Head Office Officer', 'avatar' => 'H', 'permissions' => ['dashboard', 'incoming', 'outgoing', 'internal', 'records', 'workflow', 'archive', 'search', 'notifications', 'settings']],
        'branch' => ['title' => 'Branch Officer', 'avatar' => 'B', 'permissions' => ['dashboard', 'incoming', 'outgoing', 'internal', 'search', 'notifications', 'settings']],
        'admin' => ['title' => 'System Administrator', 'avatar' => 'A', 'permissions' => ['dashboard', 'incoming', 'outgoing', 'internal', 'records', 'workflow', 'archive', 'search', 'users', 'audit', 'reports', 'notifications', 'settings']],
        'dept_manager' => ['title' => 'Department Manager', 'avatar' => 'M', 'permissions' => ['dashboard', 'incoming', 'outgoing', 'internal', 'records', 'workflow', 'search', 'reports', 'notifications', 'settings']],
        'records_officer' => ['title' => 'Records Officer', 'avatar' => 'R', 'permissions' => ['dashboard', 'incoming', 'outgoing', 'internal', 'records', 'workflow', 'archive', 'search', 'notifications', 'settings']],
        'director' => ['title' => 'Director General', 'avatar' => 'D', 'permissions' => ['dashboard', 'incoming', 'outgoing', 'internal', 'workflow', 'archive', 'search', 'audit', 'reports', 'notifications', 'settings']],
        'staff' => ['title' => 'Staff Member', 'avatar' => 'S', 'permissions' => ['dashboard', 'outgoing', 'internal', 'search', 'notifications', 'settings']]
    ];
    return isset($configs[$role]) ? $configs[$role] : null;
}

function hasPermission($permission) {
    if (!isset($_SESSION['user_role'])) return false;
    $config = getRoleConfig($_SESSION['user_role']);
    return $config && in_array($permission, $config['permissions']);
}

// Generate reference numbers
function generateRefNumber($prefix = 'INC-2025-') {
    global $pdo;
    $stmt = $pdo->prepare("SELECT MAX(CAST(SUBSTRING(ref_number, LENGTH(?) + 1) AS UNSIGNED)) as max_num 
                           FROM incoming_letters WHERE ref_number LIKE ?");
    $stmt->execute([$prefix, $prefix . '%']);
    $result = $stmt->fetch();
    $num = ($result && $result['max_num']) ? intval($result['max_num']) + 1 : 1;
    return $prefix . str_pad($num, 5, '0', STR_PAD_LEFT);
}

function generateOutRefNumber() {
    global $pdo;
    $prefix = 'OUT-2025-';
    $stmt = $pdo->prepare("SELECT MAX(CAST(SUBSTRING(ref_number, LENGTH(?) + 1) AS UNSIGNED)) as max_num 
                           FROM outgoing_letters WHERE ref_number LIKE ?");
    $stmt->execute([$prefix, $prefix . '%']);
    $result = $stmt->fetch();
    $num = ($result && $result['max_num']) ? intval($result['max_num']) + 1 : 1;
    return $prefix . str_pad($num, 5, '0', STR_PAD_LEFT);
}

function generateInternalRefNumber() {
    global $pdo;
    $prefix = 'INT-2025-';
    $stmt = $pdo->prepare("SELECT MAX(CAST(SUBSTRING(ref_number, LENGTH(?) + 1) AS UNSIGNED)) as max_num 
                           FROM internal_memos WHERE ref_number LIKE ?");
    $stmt->execute([$prefix, $prefix . '%']);
    $result = $stmt->fetch();
    $num = ($result && $result['max_num']) ? intval($result['max_num']) + 1 : 1;
    return $prefix . str_pad($num, 5, '0', STR_PAD_LEFT);
}

// CRUD operations for incoming letters
function createIncomingLetter($data) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO incoming_letters 
        (ref_number, sender_unique_num, title, description, sender_name, receiver_name, receiver_email, 
         classification, keywords, status, received_date, file_name, file_data, created_by) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    return $stmt->execute([
        $data['ref_number'],
        $data['sender_unique_num'],
        $data['title'],
        $data['description'],
        $data['sender_name'],
        $data['receiver_name'],
        $data['receiver_email'],
        $data['classification'] ?? 'General',
        $data['keywords'] ?? '',
        $data['status'] ?? 'pending',
        $data['received_date'],
        $data['file_name'] ?? null,
        $data['file_data'] ?? null,
        $_SESSION['user_name'] ?? 'System'
    ]);
}

function getIncomingLetters($filters = []) {
    global $pdo;
    $sql = "SELECT * FROM incoming_letters WHERE 1=1";
    $params = [];
    
    if (!empty($filters['status'])) {
        $sql .= " AND status = ?";
        $params[] = $filters['status'];
    }
    if (!empty($filters['receiver'])) {
        $sql .= " AND receiver_name = ?";
        $params[] = $filters['receiver'];
    }
    if (!empty($filters['sender'])) {
        $sql .= " AND sender_name = ?";
        $params[] = $filters['sender'];
    }
    if (!empty($filters['ref'])) {
        $sql .= " AND ref_number LIKE ?";
        $params[] = '%' . $filters['ref'] . '%';
    }
    if (!empty($filters['date_from'])) {
        $sql .= " AND received_date >= ?";
        $params[] = $filters['date_from'];
    }
    if (!empty($filters['date_to'])) {
        $sql .= " AND received_date <= ?";
        $params[] = $filters['date_to'];
    }
    
    $sql .= " ORDER BY created_at DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getIncomingLetter($ref) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM incoming_letters WHERE ref_number = ?");
    $stmt->execute([$ref]);
    return $stmt->fetch();
}

function updateIncomingLetter($ref, $data) {
    global $pdo;
    $fields = [];
    $params = [];
    
    foreach ($data as $key => $value) {
        if ($key !== 'ref_number') {
            $fields[] = "$key = ?";
            $params[] = $value;
        }
    }
    $params[] = $ref;
    
    $sql = "UPDATE incoming_letters SET " . implode(', ', $fields) . " WHERE ref_number = ?";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute($params);
}

// CRUD operations for outgoing letters
function createOutgoingLetter($data) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO outgoing_letters 
        (ref_number, title, description, sender_name, receiver_name, receiver_email, 
         classification, status, date, file_name, file_data, created_by) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    return $stmt->execute([
        $data['ref_number'],
        $data['title'],
        $data['description'] ?? '',
        $data['sender_name'],
        $data['receiver_name'],
        $data['receiver_email'] ?? '',
        $data['classification'] ?? 'General',
        $data['status'] ?? 'pending_approval',
        $data['date'],
        $data['file_name'] ?? null,
        $data['file_data'] ?? null,
        $_SESSION['user_name'] ?? 'System'
    ]);
}

function getOutgoingLetters($filters = []) {
    global $pdo;
    $sql = "SELECT * FROM outgoing_letters WHERE 1=1";
    $params = [];
    
    if (!empty($filters['status'])) {
        $sql .= " AND status = ?";
        $params[] = $filters['status'];
    }
    if (!empty($filters['sender'])) {
        $sql .= " AND sender_name = ?";
        $params[] = $filters['sender'];
    }
    
    $sql .= " ORDER BY created_at DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getOutgoingLetter($ref) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM outgoing_letters WHERE ref_number = ?");
    $stmt->execute([$ref]);
    return $stmt->fetch();
}

function updateOutgoingLetter($ref, $data) {
    global $pdo;
    $fields = [];
    $params = [];
    
    foreach ($data as $key => $value) {
        if ($key !== 'ref_number') {
            $fields[] = "$key = ?";
            $params[] = $value;
        }
    }
    $params[] = $ref;
    
    $sql = "UPDATE outgoing_letters SET " . implode(', ', $fields) . " WHERE ref_number = ?";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute($params);
}

// CRUD operations for internal memos
function createInternalMemo($data) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO internal_memos 
        (ref_number, title, description, sender_name, receiver_name, receiver_email, 
         status, date, file_name, file_data, created_by) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    return $stmt->execute([
        $data['ref_number'],
        $data['title'],
        $data['description'] ?? '',
        $data['sender_name'],
        $data['receiver_name'],
        $data['receiver_email'] ?? '',
        $data['status'] ?? 'pending',
        $data['date'],
        $data['file_name'] ?? null,
        $data['file_data'] ?? null,
        $_SESSION['user_name'] ?? 'System'
    ]);
}

function getInternalMemos($filters = []) {
    global $pdo;
    $sql = "SELECT * FROM internal_memos WHERE 1=1";
    $params = [];
    
    if (!empty($filters['status'])) {
        $sql .= " AND status = ?";
        $params[] = $filters['status'];
    }
    if (!empty($filters['receiver'])) {
        $sql .= " AND receiver_name = ?";
        $params[] = $filters['receiver'];
    }
    
    $sql .= " ORDER BY created_at DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getInternalMemo($ref) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM internal_memos WHERE ref_number = ?");
    $stmt->execute([$ref]);
    return $stmt->fetch();
}

function updateInternalMemo($ref, $data) {
    global $pdo;
    $fields = [];
    $params = [];
    
    foreach ($data as $key => $value) {
        if ($key !== 'ref_number') {
            $fields[] = "$key = ?";
            $params[] = $value;
        }
    }
    $params[] = $ref;
    
    $sql = "UPDATE internal_memos SET " . implode(', ', $fields) . " WHERE ref_number = ?";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute($params);
}

// A document can be reviewed by its named receiver. Supervisors and system
// administrators retain oversight access for workflow management.
function canReviewDocument($document, $type = '') {
    if (!is_array($document) || empty($_SESSION['user_name'])) {
        return false;
    }

    $pendingStatuses = $type === 'outgoing'
        ? ['pending_approval', 'draft']
        : ['pending', 'pending_approval'];
    if (!in_array($document['status'] ?? '', $pendingStatuses, true)) {
        return false;
    }

    $role = $_SESSION['user_role'] ?? '';
    $supervisorRoles = ['dept_manager', 'admin', 'director', 'head_office'];
    return in_array($role, $supervisorRoles, true)
        || (($document['receiver_name'] ?? '') === $_SESSION['user_name']);
}

// Archive completed documents and retrieve them for the archive page.
function archiveDocument($sourceTable, $document) {
    global $pdo;

    $allowedTables = ['incoming_letters', 'outgoing_letters', 'internal_memos'];
    if (!in_array($sourceTable, $allowedTables, true) || !is_array($document) || empty($document['ref_number'])) {
        return false;
    }

    $archiveData = json_encode($document, JSON_UNESCAPED_UNICODE);
    if ($archiveData === false) {
        return false;
    }

    $stmt = $pdo->prepare('SELECT id FROM archive_records WHERE original_table = ? AND ref_number = ? LIMIT 1');
    $stmt->execute([$sourceTable, $document['ref_number']]);
    $existingId = $stmt->fetchColumn();

    if ($existingId) {
        $stmt = $pdo->prepare('UPDATE archive_records SET original_id = ?, title = ?, archived_data = ?, archived_by = ?, archived_date = CURRENT_TIMESTAMP WHERE id = ?');
        return $stmt->execute([
            $document['id'] ?? null,
            $document['title'] ?? '',
            $archiveData,
            $_SESSION['user_name'] ?? 'System',
            $existingId
        ]);
    }

    $stmt = $pdo->prepare('INSERT INTO archive_records (original_table, original_id, ref_number, title, archived_data, archived_by) VALUES (?, ?, ?, ?, ?, ?)');
    return $stmt->execute([
        $sourceTable,
        $document['id'] ?? null,
        $document['ref_number'],
        $document['title'] ?? '',
        $archiveData,
        $_SESSION['user_name'] ?? 'System'
    ]);
}

function getArchivedRecords() {
    global $pdo;

    $stmt = $pdo->query('SELECT * FROM archive_records ORDER BY archived_date DESC, id DESC');
    $records = $stmt->fetchAll();
    foreach ($records as &$record) {
        $document = json_decode($record['archived_data'] ?? '', true);
        $record['document_status'] = is_array($document) ? ($document['status'] ?? 'archived') : 'archived';
    }
    unset($record);
    return $records;
}

function ensureNotificationTable() {
    global $pdo;
    static $ready = false;
    if ($ready) return;
    $pdo->exec("CREATE TABLE IF NOT EXISTS notifications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NULL,
        title VARCHAR(200) NOT NULL,
        message TEXT NOT NULL,
        type VARCHAR(50) DEFAULT 'info',
        link VARCHAR(500),
        is_read TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_notifications_user (user_id, is_read, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $ready = true;
}

function notifyUser($userId, $title, $message, $type = 'info', $link = '') {
    global $pdo;
    ensureNotificationTable();
    $stmt = $pdo->prepare('INSERT INTO notifications (user_id, title, message, type, link) VALUES (?, ?, ?, ?, ?)');
    return $stmt->execute([$userId, $title, $message, $type, $link]);
}

function notifyReceiverAboutDocument($receiverName, $title, $ref, $type) {
    global $pdo;
    $stmt = $pdo->prepare('SELECT id, email FROM users WHERE full_name = ? LIMIT 1');
    $stmt->execute([$receiverName]);
    $receiver = $stmt->fetch();
    if (!$receiver) return false;

    $label = ucfirst($type) . ' letter';
    $message = "A new {$label} ({$ref}) titled \"{$title}\" is waiting for your review.";
    notifyUser($receiver['id'], 'New letter received', $message, 'letter', 'index.php?page=' . $type);

    // Uses the server's configured mail transport. Configure SMTP/sendmail in
    // PHP for delivery on a local XAMPP installation.
    if (!empty($receiver['email']) && function_exists('mail')) {
        $subject = 'NALA ERMS: New letter received - ' . $ref;
        $body = "Hello {$receiverName},\n\n{$message}\n\nPlease sign in to NALA ERMS to review it.";
        $headers = "From: NALA ERMS <no-reply@localhost>\r\n" . "Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($receiver['email'], $subject, $body, $headers);
    }
    return true;
}

function getUnreadNotificationCount($userId) {
    global $pdo;
    ensureNotificationTable();
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0');
    $stmt->execute([$userId]);
    return (int) $stmt->fetchColumn();
}

function getUserNotifications($userId, $limit = 30) {
    global $pdo;
    ensureNotificationTable();
    $limit = max(1, min(100, (int) $limit));
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT {$limit}");
    $stmt->execute([$userId]);
    return $stmt->fetchAll();
}

function markNotificationsRead($userId) {
    global $pdo;
    ensureNotificationTable();
    $stmt = $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?');
    return $stmt->execute([$userId]);
}

function ensureWorkflowTable() {
    global $pdo;
    static $ready = false;
    if ($ready) return;
    $pdo->exec("CREATE TABLE IF NOT EXISTS workflow_rules (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(200) NOT NULL, description TEXT, trigger_event VARCHAR(100) NOT NULL, action_type VARCHAR(100) NOT NULL, action_config JSON NULL, is_active TINYINT(1) DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $ready = true;
}

function getWorkflowRules() {
    global $pdo;
    ensureWorkflowTable();
    return $pdo->query('SELECT * FROM workflow_rules ORDER BY created_at DESC')->fetchAll();
}

// Audit logging
function logAudit($user, $action, $details = '') {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO audit_logs (user_name, user_role, action, details, ip_address, user_agent) 
                           VALUES (?, ?, ?, ?, ?, ?)");
    $role = $_SESSION['user_role'] ?? 'unknown';
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    return $stmt->execute([$user, $role, $action, $details, $ip, $ua]);
}

function getAuditLogs($limit = 100) {
    global $pdo;
    $limit = max(0, (int) $limit);
    $stmt = $pdo->prepare("SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT $limit");
    $stmt->execute();
    return $stmt->fetchAll();
}

// User management
function createUser($data) {
    global $pdo;
    $firstName = trim($data['first_name'] ?? '');
    $middleName = trim($data['middle_name'] ?? '');
    $lastName = trim($data['last_name'] ?? '');
    $fullName = trim($data['full_name'] ?? '');

    if ($fullName === '') {
        $fullName = trim($firstName . ' ' . $middleName . ' ' . $lastName);
    }

    $stmt = $pdo->prepare("INSERT INTO users (username, full_name, first_name, middle_name, last_name, email, password_hash, role, department, is_active) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $password_hash = password_hash($data['password'], PASSWORD_DEFAULT);
    return $stmt->execute([
        $data['username'],
        $fullName,
        $firstName,
        $middleName,
        $lastName,
        $data['email'],
        $password_hash,
        $data['role'],
        $data['department'],
        1
    ]);
}

function updateUser($username, $data) {
    global $pdo;
    $fields = [];
    $params = [];
    
    foreach ($data as $key => $value) {
        if ($key !== 'username') {
            $fields[] = "$key = ?";
            $params[] = $value;
        }
    }
    $params[] = $username;
    
    $sql = "UPDATE users SET " . implode(', ', $fields) . " WHERE username = ?";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute($params);
}

function resetUserPassword($username, $password) {
    global $pdo;
    $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE username = ? AND role != 'admin'");
    return $stmt->execute([password_hash($password, PASSWORD_DEFAULT), $username]);
}

function setUserActive($username, $active) {
    global $pdo;
    $stmt = $pdo->prepare("UPDATE users SET is_active = ? WHERE username = ? AND role != 'admin'");
    return $stmt->execute([(int) $active, $username]);
}

function deleteUser($username) {
    global $pdo;
    $stmt = $pdo->prepare("UPDATE users SET is_active = 0 WHERE username = ? AND role != 'admin'");
    return $stmt->execute([$username]);
}

function getUsers() {
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM users ORDER BY created_at DESC");
    return $stmt->fetchAll();
}

// Search function
function searchRecords($criteria) {
    global $pdo;
    $results = [];
    $query = trim($criteria['query'] ?? '');
    if ($query === '') {
        return $results;
    }

    $searchTerm = '%' . $query . '%';
    $field = $criteria['field'] ?? 'all';

    // Keep the searchable columns explicit. This prevents a request parameter
    // from being used as a SQL column name.
    $incomingFields = [
        'reference_number' => ['ref_number'],
        'sender_unique_number' => ['sender_unique_num'],
        'sender_name' => ['sender_name'],
        'receiver_name' => ['receiver_name'],
        'keywords' => ['keywords'],
        'title' => ['title'],
        'description' => ['description']
    ];
    $standardFields = [
        'reference_number' => ['ref_number'],
        'sender_name' => ['sender_name'],
        'receiver_name' => ['receiver_name'],
        'title' => ['title'],
        'description' => ['description']
    ];

    $buildSearch = function ($table, $docType, $fields) use ($pdo, $field, $searchTerm) {
        if ($field === 'all') {
            $columns = [];
            foreach ($fields as $fieldColumns) {
                $columns = array_merge($columns, $fieldColumns);
            }
            $columns = array_values(array_unique($columns));
        } elseif (isset($fields[$field])) {
            $columns = $fields[$field];
        } else {
            return [];
        }

        $where = implode(' OR ', array_map(function ($column) {
            return "$column LIKE ?";
        }, $columns));
        $sql = "SELECT *, ? AS doc_type FROM $table WHERE ($where) ORDER BY created_at DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(array_merge([$docType], array_fill(0, count($columns), $searchTerm)));
        return $stmt->fetchAll();
    };
    
    // Search incoming
    if (empty($criteria['type']) || $criteria['type'] === 'all' || $criteria['type'] === 'incoming') {
        $results = array_merge($results, $buildSearch('incoming_letters', 'Incoming Letter', $incomingFields));
    }
    
    // Search outgoing
    if (empty($criteria['type']) || $criteria['type'] === 'all' || $criteria['type'] === 'outgoing') {
        $results = array_merge($results, $buildSearch('outgoing_letters', 'Outgoing Letter', $standardFields));
    }
    
    // Search internal
    if (empty($criteria['type']) || $criteria['type'] === 'all' || $criteria['type'] === 'internal') {
        $results = array_merge($results, $buildSearch('internal_memos', 'Internal Memo', $standardFields));
    }
    
    return $results;
}

// Dashboard statistics
function getDashboardStats() {
    global $pdo;
    $stats = [];
    
    // Count incoming
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM incoming_letters");
    $stats['incoming_count'] = $stmt->fetch()['count'];
    
    // Count outgoing
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM outgoing_letters");
    $stats['outgoing_count'] = $stmt->fetch()['count'];
    
    // Count internal
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM internal_memos");
    $stats['internal_count'] = $stmt->fetch()['count'];
    
    // Count pending approvals
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM incoming_letters WHERE status IN ('pending', 'pending_approval')");
    $stats['pending_incoming'] = $stmt->fetch()['count'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM outgoing_letters WHERE status = 'pending_approval'");
    $stats['pending_outgoing'] = $stmt->fetch()['count'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM internal_memos WHERE status = 'pending'");
    $stats['pending_internal'] = $stmt->fetch()['count'];
    
    // Count approved
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM incoming_letters WHERE status = 'approved'");
    $stats['approved_incoming'] = $stmt->fetch()['count'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM outgoing_letters WHERE status = 'approved'");
    $stats['approved_outgoing'] = $stmt->fetch()['count'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM internal_memos WHERE status = 'approved'");
    $stats['approved_internal'] = $stmt->fetch()['count'];

    $stmt = $pdo->query("SELECT COUNT(*) as count FROM incoming_letters WHERE status = 'rejected'");
    $stats['rejected_incoming'] = $stmt->fetch()['count'];
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM outgoing_letters WHERE status = 'rejected'");
    $stats['rejected_outgoing'] = $stmt->fetch()['count'];
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM internal_memos WHERE status = 'rejected'");
    $stats['rejected_internal'] = $stmt->fetch()['count'];
    
    return $stats;
}

// Get recent records
function getRecentRecords($limit = 5) {
    global $pdo;
    $records = [];
    $limit = max(0, (int) $limit);
    
    $stmt = $pdo->prepare("SELECT ref_number, title, sender_name, receiver_name, status, received_date as date, 'Incoming' as type 
                           FROM incoming_letters ORDER BY created_at DESC LIMIT $limit");
    $stmt->execute();
    $records = array_merge($records, $stmt->fetchAll());
    
    $stmt = $pdo->prepare("SELECT ref_number, title, sender_name, receiver_name, status, date, 'Outgoing' as type 
                           FROM outgoing_letters ORDER BY created_at DESC LIMIT $limit");
    $stmt->execute();
    $records = array_merge($records, $stmt->fetchAll());
    
    $stmt = $pdo->prepare("SELECT ref_number, title, sender_name, receiver_name, status, date, 'Internal' as type 
                           FROM internal_memos ORDER BY created_at DESC LIMIT $limit");
    $stmt->execute();
    $records = array_merge($records, $stmt->fetchAll());
    
    usort($records, function($a, $b) {
        return strtotime($b['date']) - strtotime($a['date']);
    });
    
    return array_slice($records, 0, $limit);
}

// Helper: Get avatar HTML
function getAvatarHTML($username, $size = '36px') {
    $user = getUserByUsername($username);
    if (!$user) {
        return '<div class="ua-avatar" style="width:' . $size . ';height:' . $size . ';background:#0a1e3a;color:#fff;display:flex;align-items:center;justify-content:center;border-radius:50%;font-weight:600;">' . strtoupper(substr($username, 0, 1)) . '</div>';
    }
    if ($user['photo']) {
        return '<div class="ua-avatar" style="width:' . $size . ';height:' . $size . ';overflow:hidden;border-radius:50%;flex-shrink:0;"><img src="' . $user['photo'] . '" alt="' . $user['full_name'] . '" style="width:100%;height:100%;object-fit:cover;" /></div>';
    } else {
        return '<div class="ua-avatar" style="width:' . $size . ';height:' . $size . ';background:#0a1e3a;color:#fff;display:flex;align-items:center;justify-content:center;border-radius:50%;font-weight:600;flex-shrink:0;">' . strtoupper(substr($user['full_name'], 0, 1)) . '</div>';
    }
}

// Status pill HTML
function getStatusPill($status) {
    $classes = [
        'pending' => 'pending',
        'pending_approval' => 'pending_approval',
        'approved' => 'approved',
        'rejected' => 'rejected',
        'in-process' => 'in-process',
        'archived' => 'archived',
        'dispatched' => 'dispatched',
        'completed' => 'completed',
        'registered' => 'registered'
    ];
    $class = isset($classes[$status]) ? $classes[$status] : 'pending';
    return '<span class="status-pill ' . $class . '">' . str_replace('_', ' ', $status) . '</span>';
}

// File upload helper
function uploadFile($file, $target_dir = null) {
    // Resolve this from the application directory so uploads work regardless
    // of which action script handled the request.
    if ($target_dir === null) {
        $target_dir = __DIR__ . '/../uploads/';
    }
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    
    $file_name = time() . '_' . basename($file['name']);
    $target_file = $target_dir . $file_name;
    $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    
    // Check if image file is a actual image or fake image
    $check = getimagesize($file['tmp_name']);
    if ($check !== false) {
        if (move_uploaded_file($file['tmp_name'], $target_file)) {
            return $file_name;
        }
    } elseif (in_array($file_type, ['pdf', 'doc', 'docx', 'xls', 'xlsx'])) {
        if (move_uploaded_file($file['tmp_name'], $target_file)) {
            return $file_name;
        }
    }
    return false;
}

// JSON response helper
function jsonResponse($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['user_name']);
}

// Require login
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}
?>
