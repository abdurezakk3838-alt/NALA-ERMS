<?php
// pages/settings.php
$user = getUserByUsername($_SESSION['username'] ?? '');
$success_message = $_SESSION['flash_message'] ?? '';
$success_type = $_SESSION['flash_type'] ?? 'success';
if (!empty($success_message)) {
    unset($_SESSION['flash_message']);
    unset($_SESSION['flash_type']);
}
?>

<div class="max-w-4xl mx-auto space-y-6">
    <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
        <div class="flex items-center justify-between flex-wrap gap-3 mb-4">
            <div>
                <h2 class="text-xl font-bold text-gray-800"><i class="fas fa-user-cog text-blue-600 mr-2"></i>Profile & Security</h2>
                <p class="text-sm text-gray-500">Update your profile details and change your password.</p>
            </div>
        </div>

        <?php if (!empty($success_message)): ?>
        <div class="mb-4 rounded-lg border px-4 py-3 text-sm <?php echo $success_type === 'error' ? 'border-red-200 bg-red-50 text-red-700' : 'border-emerald-200 bg-emerald-50 text-emerald-700'; ?>">
            <?php echo htmlspecialchars($success_message); ?>
        </div>
        <?php endif; ?>

        <form action="actions/update_profile.php" method="POST" enctype="multipart/form-data" class="space-y-5">
            <div class="border-b pb-5">
                <label class="form-label">Profile Photo</label>
                <div class="flex items-center gap-4 flex-wrap">
                    <div class="w-20 h-20 rounded-full overflow-hidden bg-slate-800 text-white flex items-center justify-center font-bold text-2xl shrink-0">
                        <?php if (!empty($user['photo'])): ?>
                            <img id="profilePhotoPreview" src="<?php echo htmlspecialchars($user['photo']); ?>" alt="Current profile photo" class="w-full h-full object-cover" />
                        <?php else: ?>
                            <img id="profilePhotoPreview" src="" alt="Profile photo preview" class="w-full h-full object-cover hidden" />
                            <span id="profilePhotoInitial"><?php echo htmlspecialchars(strtoupper(substr($user['full_name'] ?? 'U', 0, 1))); ?></span>
                        <?php endif; ?>
                    </div>
                    <div>
                        <input type="file" id="profilePhoto" name="profile_photo" accept="image/jpeg,image/png,image/gif,image/webp" class="block w-full text-sm text-gray-600 file:mr-3 file:py-2 file:px-3 file:rounded-lg file:border-0 file:bg-blue-50 file:text-blue-700 file:font-semibold hover:file:bg-blue-100" />
                        <?php if (!empty($user['photo'])): ?>
                            <label class="inline-flex items-center gap-2 mt-2 text-sm text-red-600"><input type="checkbox" name="remove_photo" value="1" /> Remove profile photo</label>
                        <?php endif; ?>
                        <p class="text-xs text-gray-500 mt-1">JPG, PNG, GIF, or WebP. Maximum size: 2 MB.</p>
                    </div>
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="form-label">Full Name</label>
                    <input type="text" name="full_name" class="form-control" value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>" required />
                </div>
                <div>
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required />
                </div>
                <div>
                    <label class="form-label">Department</label>
                    <input type="text" name="department" class="form-control" value="<?php echo htmlspecialchars($user['department'] ?? ''); ?>" />
                </div>
                <div>
                    <label class="form-label">Username</label>
                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['username'] ?? ''); ?>" readonly />
                </div>
            </div>

            <div class="border-t pt-4">
                <h3 class="font-semibold text-gray-800 mb-3"><i class="fas fa-lock text-slate-500 mr-2"></i>Change Password</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">Current Password</label>
                        <input type="password" name="current_password" class="form-control" placeholder="Enter your current password" />
                    </div>
                    <div>
                        <label class="form-label">New Password</label>
                        <input type="password" name="new_password" class="form-control" placeholder="Enter a new password" />
                    </div>
                </div>
            </div>

            <div class="border-t pt-4">
                <label class="form-label">Language / ቋንቋ / Lugha</label>
                <select name="language" class="form-control md:w-80">
                    <option value="en" <?= ($_SESSION['language'] ?? 'en') === 'en' ? 'selected' : '' ?>>English</option>
                    <option value="am" <?= ($_SESSION['language'] ?? 'en') === 'am' ? 'selected' : '' ?>>አማርኛ (Amharic)</option>
                    <option value="sw" <?= ($_SESSION['language'] ?? 'en') === 'sw' ? 'selected' : '' ?>>Kiswahili</option>
                </select>
            </div>

            <div class="flex justify-end gap-3">
                <button type="submit" class="btn-success"><i class="fas fa-save"></i> Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
document.getElementById('profilePhoto')?.addEventListener('change', function () {
    const file = this.files[0];
    if (!file) return;
    const preview = document.getElementById('profilePhotoPreview');
    const initial = document.getElementById('profilePhotoInitial');
    preview.src = URL.createObjectURL(file);
    preview.classList.remove('hidden');
    if (initial) initial.classList.add('hidden');
});
</script>
